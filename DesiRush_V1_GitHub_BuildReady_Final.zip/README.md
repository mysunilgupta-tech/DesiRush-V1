# Desi Rush V1

Offline / no-login Unity Android runner prototype.

Unity version: 2022.3.40f1

The GitHub Actions workflow extracts this project ZIP and builds an Android APK.
