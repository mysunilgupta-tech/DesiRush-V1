# Desi Rush V1 — Final Offline / No Login

Final V1 Unity source checkpoint for Android testing.

- 3D runner gameplay
- Swipe lane movement and jump
- Coins and score
- Local save/high score
- Pause / game over / retry
- No mandatory login
- Offline-first core gameplay
- Android build workflow included

## Build
Unity 2022.3.40f1. Use the GitHub Actions workflow in `.github/workflows/android-apk.yml` to create a test APK.
