# Offline / No Login Guarantee — V1

The supplied V1 source contains no authentication or account-login implementation.

There are no references/dependencies for Firebase Authentication, Google Sign-In, or another account system in the V1 source package.

The main scene boot path is:
`Bootstrap -> GameManager + Player + RunnerField + UIManager`

Gameplay can therefore begin without creating or signing into an account. Local progress is stored using Unity PlayerPrefs.

If online services, ads, cloud save, or social features are added later, they should remain optional so that the basic V1 gameplay path continues to work without login.
