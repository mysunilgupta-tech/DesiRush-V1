# V1 Final Build Notes

## Offline / no-login status
The V1 gameplay path is intentionally account-free. There is no login screen and no authentication SDK in the supplied source. The player can launch directly into gameplay.

Core save data uses local Unity `PlayerPrefs`:
- Coins
- High Score

Internet/backend services are not required for the core V1 gameplay loop.

## Android release
1. Open with Unity 2022.3.40f1.
2. Ensure Android Build Support is installed.
3. Open `Assets/Scenes/Main.unity`.
4. Test touch/swipe, jump, coins, pause, collision/game-over and retry.
5. Set the Android package identifier and app icon.
6. For Play Store release, configure a release keystore and build an Android App Bundle (AAB).
7. Complete Play Console testing/release steps.

The source package itself has not been compiled into an APK/AAB in this environment.
