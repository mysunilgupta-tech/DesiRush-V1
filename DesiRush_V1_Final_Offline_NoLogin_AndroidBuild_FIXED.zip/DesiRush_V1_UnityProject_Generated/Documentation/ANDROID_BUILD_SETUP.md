# Desi Rush V1 — Android Build Setup

This checkpoint is prepared for a mobile-only build workflow.

## Project
- Unity: 2022.3.40f1
- Entry scene: Assets/Scenes/Main.unity
- Build method: BuildScript.BuildAndroid
- Output: Builds/Android/DesiRush-V1.apk

## GitHub Actions
The workflow is `.github/workflows/android-apk.yml` and is started manually with **Run workflow**.

The repository must contain these GitHub Actions secrets:
- `UNITY_LICENSE`
- `UNITY_EMAIL`
- `UNITY_PASSWORD`

Use the Unity account/license information associated with the project. Never put credentials directly in the workflow or source files.

## Important
The workflow builds an APK for testing. A signed Android App Bundle (AAB) for Google Play should be prepared separately after the APK has been tested on a real Android phone.
