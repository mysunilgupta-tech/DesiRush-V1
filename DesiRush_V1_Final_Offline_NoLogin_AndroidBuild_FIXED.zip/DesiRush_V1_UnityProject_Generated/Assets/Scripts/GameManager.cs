using UnityEngine;
using UnityEngine.SceneManagement;
public class GameManager:MonoBehaviour{
 public static GameManager I; public int score,runCoins; public bool running,paused;
 void Awake(){if(I&&I!=this){Destroy(gameObject);return;}I=this;DontDestroyOnLoad(gameObject);}
 void Start(){BeginRun();}
 public void BeginRun(){score=0;runCoins=0;running=true;paused=false;Time.timeScale=1;UIManager.I?.ShowGameplay();}
 public void AddCoin(){runCoins++;score+=10;SaveData.Coins++;SaveData.Save();}
 public void EndRun(){if(!running)return;running=false;Time.timeScale=1;if(score>SaveData.HighScore)SaveData.HighScore=score;SaveData.Save();UIManager.I?.ShowGameOver();}
 public void TogglePause(){if(!running)return;paused=!paused;Time.timeScale=paused?0:1;UIManager.I?.ShowPause(paused);}
 public void Retry(){Time.timeScale=1;SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);}
 public void Home(){Retry();}
}
