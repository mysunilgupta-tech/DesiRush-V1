using UnityEngine;
public static class SaveData{
 public static int Coins{get=>PlayerPrefs.GetInt("DR_COINS",0);set=>PlayerPrefs.SetInt("DR_COINS",Mathf.Max(0,value));}
 public static int HighScore{get=>PlayerPrefs.GetInt("DR_HIGH",0);set=>PlayerPrefs.SetInt("DR_HIGH",Mathf.Max(0,value));}
 public static void Save()=>PlayerPrefs.Save();
}
