using UnityEngine;
public class PlayerRunner:MonoBehaviour{
 public float laneWidth=2.5f,speed=10f,jumpForce=7f; int lane=1; Vector2 start; bool grounded=true; Rigidbody rb;
 void Awake(){rb=gameObject.AddComponent<Rigidbody>();rb.constraints=RigidbodyConstraints.FreezeRotation;}
 void Update(){if(GameManager.I==null||!GameManager.I.running||GameManager.I.paused)return;transform.position=new Vector3(Mathf.Lerp(transform.position.x,(lane-1)*laneWidth,Time.deltaTime*12),transform.position.y,transform.position.z+speed*Time.deltaTime);if(Input.GetKeyDown(KeyCode.LeftArrow))Move(-1);if(Input.GetKeyDown(KeyCode.RightArrow))Move(1);if(Input.GetKeyDown(KeyCode.UpArrow))Jump();if(Input.touchCount>0){var t=Input.GetTouch(0);if(t.phase==TouchPhase.Began)start=t.position;if(t.phase==TouchPhase.Ended){var d=t.position-start;if(d.magnitude>60){if(Mathf.Abs(d.x)>Mathf.Abs(d.y))Move(d.x>0?1:-1);else if(d.y>0)Jump();}}}}
 void Move(int d){lane=Mathf.Clamp(lane+d,0,2);} void Jump(){if(!grounded)return;grounded=false;rb.AddForce(Vector3.up*jumpForce,ForceMode.VelocityChange);} void OnCollisionEnter(Collision c){if(c.collider.CompareTag("Obstacle"))GameManager.I.EndRun();if(c.collider.CompareTag("Ground"))grounded=true;}
}
