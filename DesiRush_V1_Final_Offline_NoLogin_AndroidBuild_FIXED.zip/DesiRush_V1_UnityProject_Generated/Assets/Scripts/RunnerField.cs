using UnityEngine;using System.Collections.Generic;
public class RunnerField:MonoBehaviour{
 public Transform player;public float length=30,spawnAhead=180,cleanupBehind=45;List<GameObject> segs=new();float next;
 void Start(){for(int i=0;i<8;i++)Spawn();}
 void Update(){if(!player)return;while(next<player.position.z+spawnAhead)Spawn();for(int i=segs.Count-1;i>=0;i--)if(segs[i].transform.position.z<player.position.z-cleanupBehind){Destroy(segs[i]);segs.RemoveAt(i);}}
 void Spawn(){var r=new GameObject("RoadSegment");r.transform.position=new Vector3(0,0,next);var road=GameObject.CreatePrimitive(PrimitiveType.Cube);road.transform.SetParent(r.transform);road.transform.localPosition=new Vector3(0,-.5f,length/2);road.transform.localScale=new Vector3(9,1,length);road.tag="Ground";for(int l=0;l<3;l++){float x=(l-1)*2.5f;if(Random.value<.65f){var o=GameObject.CreatePrimitive(PrimitiveType.Cube);o.transform.SetParent(r.transform);o.transform.localPosition=new Vector3(x,.8f,Random.Range(5,25));o.transform.localScale=new Vector3(1.5f,1.6f,1.5f);o.tag="Obstacle";}if(Random.value<.8f){var c=GameObject.CreatePrimitive(PrimitiveType.Sphere);c.transform.SetParent(r.transform);c.transform.localPosition=new Vector3(x,1.2f,Random.Range(3,27));c.transform.localScale=.45f*Vector3.one;c.tag="Coin";c.GetComponent<Collider>().isTrigger=true;c.AddComponent<CoinPickup>();}}segs.Add(r);next+=length;}
}
