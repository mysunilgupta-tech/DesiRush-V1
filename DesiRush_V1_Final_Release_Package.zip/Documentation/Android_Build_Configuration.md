# Android Build Configuration
- Platform: Android
- Testing build: APK
- Production release: signed AAB
- Architecture: ARM64
- Orientation: Landscape

Actual compilation requires the complete Unity project and release signing configuration.
