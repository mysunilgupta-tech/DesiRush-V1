# Desi Rush: India Survival — Generated V1 Unity Project

This is a newly generated Unity project skeleton based on the available Step 43 documentation and the V1 checkpoints. It is NOT the original historical Unity project.

Open with Unity 2022.3 LTS or newer LTS. Open Assets/Scenes/Main.unity and press Play.

Included: runtime-generated 3-lane runner field, road segments, obstacles, coins, swipe/lane controls, pause/game-over state, and local score/coin save.

This package is source/project skeleton only. APK/AAB is not included.
