# V1 Build Notes

This generated project is a source skeleton, not the historical original Unity project.

1. Open with Unity 2022.3 LTS or newer LTS.
2. Open Assets/Scenes/Main.unity.
3. Add Android Build Support if needed.
4. Test in Editor and on an Android device.
5. Configure release signing before AAB generation.
6. Device QA and APK/AAB compilation have not been performed by this package.
